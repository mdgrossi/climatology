### clipy

A makeshift Python library for calculating and plotting climatology records